package com.example.tfg_junio_java;

public class Avatar {

    public int foto;

    public Avatar(int foto) {
        this.foto = foto;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }
}
